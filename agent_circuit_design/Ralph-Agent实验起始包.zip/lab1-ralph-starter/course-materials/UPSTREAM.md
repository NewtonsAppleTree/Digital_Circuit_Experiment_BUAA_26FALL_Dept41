# Ralph upstream provenance

- Repository: https://github.com/snarktank/ralph
- Upstream branch: `main`
- Pinned revision: `6c53cb0b831ebe8739c6a003e22af14902d8b0b5`
- Revision checked: 2026-09-10
- Imported concepts/files: `ralph.sh` and the base `CLAUDE.md` agent prompt
- License: MIT; the upstream notice is preserved in `LICENSE.upstream`

## Local changes

- Claude Code is the only supported coding agent.
- The prompt is specialized for direct `rtl/` editing and Make/Verilator gates.
- Dirty-worktree continuation is explicit so failed attempts survive fresh contexts.
- `--question` / `--question-file` accept optional user task context.
- Repeated `--image` flags attach zero or more local images to that context.
- Runtime input and iteration logs live under ignored `.runtime/` state.
- A reported completion is accepted only after the launcher independently checks
  every PRD Story and reruns `make test` successfully.
