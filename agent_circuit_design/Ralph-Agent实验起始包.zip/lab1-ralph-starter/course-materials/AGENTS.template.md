# RTL Agent Project Rules

- REQUIREMENTS.md 是需求依据；README.md 补充接口布局和时序。
- Makefile、REQUIREMENTS.md、tb/ 为只读验收基础。
- 直接修改 rtl/*.sv，不使用历史 agent/ Python 控制器。
- Level1 必须使用 19 位五级 Kogge-Stone 前缀网络。
- Level2 使用八个部分积、CSA 压缩和 Level1 末级加法器。
- Level3 使用 4×4 定权重 PE 阵列，每个 PE 有输出寄存器。
- RTL 乘法数据通路不得用行为级乘法替代规定结构。
- Level3 矩阵低位起、行优先；rst_n 低有效异步复位。
- load=1 装载权重并冲刷流水；已完成的 res 保持。
- load=0 的第一个上升沿捕获输入，再等 11 个上升沿完成。
- 下一矩阵事务必须重新脉冲 load，权重不变也一样。
- 保留失败后的工作树修改，禁止自动 reset 或 clean。
- 局部通过后仍须执行全局 make test，检查低层改动的影响。
