#!/usr/bin/env bash
# Ralph Wiggum - long-running RTL coding-agent loop.
# Based on snarktank/ralph; see UPSTREAM.md for the pinned revision.

set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
PRD_FILE="$SCRIPT_DIR/prd.json"
PROGRESS_FILE="$SCRIPT_DIR/progress.txt"
ARCHIVE_DIR="$SCRIPT_DIR/archive"
LAST_BRANCH_FILE="$SCRIPT_DIR/.last-branch"
RUNTIME_DIR="$SCRIPT_DIR/.runtime"
TASK_INPUT_FILE="$RUNTIME_DIR/task-input.json"

TOOL="claude"
MAX_ITERATIONS=10
ITERATION_COUNT_PROVIDED=false
QUESTION=""
QUESTION_FILE=""
QUESTION_PROVIDED=false
DRY_RUN=false
IMAGE_PATHS=()

usage() {
  cat <<'EOF'
Usage:
  ./scripts/ralph/ralph.sh [options] [max_iterations]

Options:
  --tool claude          Coding agent (only claude is supported).
  --question TEXT        Optional supplemental problem statement.
  --question-file FILE   Read the supplemental problem from a UTF-8 file.
  --image FILE           Attach an optional image; may be repeated.
  --dry-run              Validate inputs and print normalized task input only.
  -h, --help             Show this help.

Examples:
  ./scripts/ralph/ralph.sh --tool claude 30
  ./scripts/ralph/ralph.sh --question "修复 Level2 乘法错误" 20
  ./scripts/ralph/ralph.sh --question-file issue.md --image waveform.png 20

Images are optional, but every --image requires --question or --question-file.
The question and images supplement the PRD; they do not override requirements or tests.
EOF
}

require_value() {
  local option="$1"
  local value="${2-}"
  if [[ -z "$value" ]]; then
    echo "Error: $option requires a value." >&2
    usage >&2
    exit 2
  fi
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --tool)
      require_value "$1" "${2-}"
      TOOL="$2"
      shift 2
      ;;
    --tool=*)
      TOOL="${1#*=}"
      shift
      ;;
    --question)
      require_value "$1" "${2-}"
      QUESTION="$2"
      QUESTION_PROVIDED=true
      shift 2
      ;;
    --question=*)
      QUESTION="${1#*=}"
      QUESTION_PROVIDED=true
      shift
      ;;
    --question-file)
      require_value "$1" "${2-}"
      QUESTION_FILE="$2"
      shift 2
      ;;
    --question-file=*)
      QUESTION_FILE="${1#*=}"
      shift
      ;;
    --image)
      require_value "$1" "${2-}"
      IMAGE_PATHS+=("$2")
      shift 2
      ;;
    --image=*)
      IMAGE_PATHS+=("${1#*=}")
      shift
      ;;
    --dry-run)
      DRY_RUN=true
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    --)
      shift
      break
      ;;
    -*)
      echo "Error: unknown option '$1'." >&2
      usage >&2
      exit 2
      ;;
    *)
      if [[ "$1" =~ ^[1-9][0-9]*$ ]]; then
        if [[ "$ITERATION_COUNT_PROVIDED" == true ]]; then
          echo "Error: max_iterations may be provided only once." >&2
          exit 2
        fi
        MAX_ITERATIONS="$1"
        ITERATION_COUNT_PROVIDED=true
      else
        echo "Error: expected a positive iteration count, got '$1'." >&2
        usage >&2
        exit 2
      fi
      shift
      ;;
  esac
done

if [[ $# -gt 0 ]]; then
  echo "Error: unexpected trailing arguments: $*" >&2
  exit 2
fi

if [[ "$TOOL" != "claude" ]]; then
  echo "Error: unsupported tool '$TOOL'; this project uses Claude Code." >&2
  exit 2
fi

for command_name in jq git make; do
  if ! command -v "$command_name" >/dev/null 2>&1; then
    echo "Error: required command '$command_name' was not found." >&2
    exit 1
  fi
done

if [[ ! -f "$PRD_FILE" ]]; then
  echo "Error: missing PRD: $PRD_FILE" >&2
  exit 1
fi

if ! jq -e '
  (.branchName | type == "string" and length > 0) and
  (.userStories | type == "array" and length > 0) and
  ([.userStories[] | (.id | type == "string") and
                     (.priority | type == "number") and
                     (.acceptanceCommand | type == "string" and length > 0) and
                     (.passes | type == "boolean")] | all)
' "$PRD_FILE" >/dev/null; then
  echo "Error: $PRD_FILE does not match the required Ralph PRD shape." >&2
  exit 1
fi

if [[ -n "$QUESTION_FILE" && "$QUESTION_PROVIDED" == true ]]; then
  echo "Error: use either --question or --question-file, not both." >&2
  exit 2
fi

if [[ -n "$QUESTION_FILE" ]]; then
  if [[ ! -f "$QUESTION_FILE" || ! -r "$QUESTION_FILE" ]]; then
    echo "Error: question file is not a readable file: $QUESTION_FILE" >&2
    exit 2
  fi
  QUESTION="$(<"$QUESTION_FILE")"
  QUESTION_PROVIDED=true
fi

if [[ "$QUESTION_PROVIDED" == true && -z "$QUESTION" ]]; then
  echo "Error: the supplemental question must not be empty." >&2
  exit 2
fi

if [[ ${#IMAGE_PATHS[@]} -gt 0 && "$QUESTION_PROVIDED" != true ]]; then
  echo "Error: --image requires --question or --question-file." >&2
  exit 2
fi

NORMALIZED_IMAGES=()
for image_path in "${IMAGE_PATHS[@]}"; do
  if [[ ! -f "$image_path" || ! -r "$image_path" ]]; then
    echo "Error: image is not a readable file: $image_path" >&2
    exit 2
  fi
  lower_path="${image_path,,}"
  case "$lower_path" in
    *.png|*.jpg|*.jpeg|*.webp|*.gif) ;;
    *)
      echo "Error: unsupported image type: $image_path" >&2
      echo "Supported extensions: png, jpg, jpeg, webp, gif." >&2
      exit 2
      ;;
  esac
  image_dir="$(cd "$(dirname "$image_path")" && pwd -P)"
  NORMALIZED_IMAGES+=("$image_dir/$(basename "$image_path")")
done

mkdir -p "$RUNTIME_DIR"
IMAGES_JSON='[]'
for image_path in "${NORMALIZED_IMAGES[@]}"; do
  IMAGES_JSON="$(jq --arg path "$image_path" '. + [$path]' <<<"$IMAGES_JSON")"
done

task_input_tmp="$TASK_INPUT_FILE.tmp"
if [[ "$QUESTION_PROVIDED" == true ]]; then
  jq -n \
    --arg question "$QUESTION" \
    --argjson images "$IMAGES_JSON" \
    '{question: $question, images: $images}' > "$task_input_tmp"
else
  jq -n '{question: null, images: []}' > "$task_input_tmp"
fi
mv "$task_input_tmp" "$TASK_INPUT_FILE"

if [[ "$DRY_RUN" == true ]]; then
  echo "Ralph input is valid. Normalized task input:"
  jq . "$TASK_INPUT_FILE"
  exit 0
fi

if ! command -v claude >/dev/null 2>&1; then
  echo "Error: Claude Code executable 'claude' was not found." >&2
  exit 1
fi

cd "$REPO_ROOT"
if [[ "$(git rev-parse --show-toplevel)" != "$REPO_ROOT" ]]; then
  echo "Error: $REPO_ROOT is not the Git worktree root." >&2
  exit 1
fi

TARGET_BRANCH="$(jq -r '.branchName' "$PRD_FILE")"
CURRENT_BRANCH="$(git branch --show-current)"
if [[ "$CURRENT_BRANCH" != "$TARGET_BRANCH" ]]; then
  if [[ -n "$(git status --porcelain)" ]]; then
    echo "Error: the worktree is dirty on '$CURRENT_BRANCH'." >&2
    echo "Establish and commit the baseline before switching to '$TARGET_BRANCH'." >&2
    exit 1
  fi
  if git show-ref --verify --quiet "refs/heads/$TARGET_BRANCH"; then
    git switch "$TARGET_BRANCH"
  else
    git switch -c "$TARGET_BRANCH"
  fi
fi

mkdir -p "$ARCHIVE_DIR" "$RUNTIME_DIR"
if [[ -f "$LAST_BRANCH_FILE" ]]; then
  LAST_BRANCH="$(<"$LAST_BRANCH_FILE")"
  if [[ -n "$LAST_BRANCH" && "$LAST_BRANCH" != "$TARGET_BRANCH" ]]; then
    archive_name="$(date +%Y-%m-%d)-${LAST_BRANCH#ralph/}"
    archive_dir="$ARCHIVE_DIR/$archive_name"
    mkdir -p "$archive_dir"
    cp "$PRD_FILE" "$archive_dir/prd.json"
    if [[ -f "$PROGRESS_FILE" ]]; then
      cp "$PROGRESS_FILE" "$archive_dir/progress.txt"
    fi
  fi
fi
printf '%s\n' "$TARGET_BRANCH" > "$LAST_BRANCH_FILE"

if [[ ! -f "$PROGRESS_FILE" ]]; then
  cat > "$PROGRESS_FILE" <<'EOF'
# Ralph Progress Log

## Codebase Patterns

---
EOF
fi

echo "Starting Ralph - Tool: $TOOL - Max iterations: $MAX_ITERATIONS"
if [[ "$QUESTION_PROVIDED" == true ]]; then
  echo "Supplemental question: yes; images: ${#NORMALIZED_IMAGES[@]}"
else
  echo "Supplemental question: no; using repository PRD only"
fi

for ((iteration = 1; iteration <= MAX_ITERATIONS; iteration++)); do
  echo
  echo "==============================================================="
  echo "  Ralph Iteration $iteration of $MAX_ITERATIONS ($TOOL)"
  echo "==============================================================="

  iteration_log="$RUNTIME_DIR/iteration-$iteration.log"
  claude --dangerously-skip-permissions --print < "$SCRIPT_DIR/CLAUDE.md" \
    2>&1 | tee "$iteration_log" || true

  if grep -q '<promise>COMPLETE</promise>' "$iteration_log"; then
    if ! jq -e '[.userStories[].passes] | all' "$PRD_FILE" >/dev/null; then
      echo "Ignored premature COMPLETE: at least one PRD story still has passes=false." >&2
    else
      echo "Claude reported completion; independently running the final gate..."
      final_log="$RUNTIME_DIR/final-test.log"
      if make test 2>&1 | tee "$final_log"; then
        echo "Ralph completed all stories and make test passed."
        echo "Completed at iteration $iteration of $MAX_ITERATIONS."
        exit 0
      fi

      cat >> "$PROGRESS_FILE" <<EOF

## $(date '+%Y-%m-%d %H:%M:%S') - FINAL REGRESSION - FAIL
- command: make test
- result: non-zero exit; see $final_log
- next: keep the current worktree and repair the regression before declaring COMPLETE
---
EOF
      echo "Final gate failed; continuing with a fresh Claude context." >&2
    fi
  fi

  echo "Iteration $iteration complete. Continuing..."
  sleep 2
done

echo
echo "Ralph reached max iterations ($MAX_ITERATIONS) without verified completion."
echo "Check $PROGRESS_FILE and $RUNTIME_DIR for status."
exit 1
