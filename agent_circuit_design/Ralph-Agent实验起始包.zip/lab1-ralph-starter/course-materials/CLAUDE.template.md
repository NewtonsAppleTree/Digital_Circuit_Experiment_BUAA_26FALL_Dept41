# Ralph RTL Agent Instructions

你是本项目的 RTL 编码 Agent。每轮只处理一个最高优先级未完成 Story。
Ralph 已将工作区放到 PRD 指定分支；不要自行切换分支。

## 1. 按顺序读取状态
1. 读取 scripts/ralph/prd.json。
2. 读取 scripts/ralph/progress.txt，先看 Codebase Patterns。
3. 读取 scripts/ralph/.runtime/task-input.json。
   question 为可选补充问题；images 可以为空。
   如有图片，先查看全部图片，再修改代码。
4. 阅读 REQUIREMENTS.md、README.md、根目录 AGENTS.md 和 Makefile。
5. 检查 git status、git diff、近期 git log。
6. 阅读当前 Story 相关 RTL 和 tb/ 测试。

## 2. 选择当前 Story
选择 priority 数值最小且 passes=false 的 Story。
每轮只推进当前 Story；不要一次性把三个任务全部标记通过。
若所有 Story 已通过，进入全局回归；失败时修复回归问题。

## 3. 保留失败状态
未提交 RTL 修改可能来自上一轮失败尝试。
先分析差异和 progress，保留有用修改并继续修复。
不要执行 reset、checkout 丢弃文件或 clean 清除工作。
需要替换旧思路时，在 progress 解释原因。

## 4. 实现约束
直接实现 rtl/*.sv 中的接口骨架，保持端口不变。
遵守 REQUIREMENTS.md 与 PRD 的结构、数值和时序要求。
不使用历史 agent/ Python 控制器，不复制外部参考实现。
Makefile、REQUIREMENTS.md、tb/ 是只读验收基础。
禁止修改参考模型、跳过测试、硬编码测试向量或伪造通过。

## 5. 验证当前 Story
原样执行当前 Story 的 acceptanceCommand。
只有命令实际退出码为 0，才允许将当前 Story 标记 passes=true。
结构约束也须自行检查，功能测试不能替代结构检查。

## 6. 失败时
保持 passes=false，保留有用 RTL 修改，不创建成功提交。
追加 progress：Story、修改文件、命令、退出码、关键错误、
当前假设与下一轮建议。随后正常结束本轮，让下一轮继续。

## 7. 成功时
只更新当前 Story 的 passes=true。
追加 progress：改动、验收证据与可复用经验。
将 RTL、prd.json 与 progress.txt 一起提交。
提交说明使用 feat: [US-xxx] - [任务名称]。
仅在有长期工程知识时更新 AGENTS.md 或 Codebase Patterns。
仍有其他未完成 Story 时，正常结束本轮。

## 8. 全局完成门禁
所有 Story 通过后，必须执行 make test 并确认退出码为 0。
检查没有改弱验收，记录最终 PASS，并保存相关状态提交。
只有满足这些条件，才输出以下完成标记：
<promise>COMPLETE</promise>
若全局回归失败，不输出该标记；保留代码并记录原因，继续修复。
