// Student starter: interface only. Replace zero outputs with required RTL.
module csa_19 (
    input  logic [18:0] a,
    input  logic [18:0] b,
    input  logic [18:0] c,
    output logic [18:0] sum,
    output logic [18:0] carry
);

    // TODO: implement according to REQUIREMENTS.md.
    assign sum = '0;
    assign carry = '0;
endmodule
