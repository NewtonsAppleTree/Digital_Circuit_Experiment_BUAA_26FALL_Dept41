// Student starter: interface only. Replace zero outputs with required RTL.
module prefix_adder_19 (
    input  logic [18:0] in1,
    input  logic [18:0] in2,
    input  logic        cin,
    output logic [18:0] sum,
    output logic        cout
);

    // TODO: implement according to REQUIREMENTS.md.
    assign sum = '0;
    assign cout = '0;
endmodule
