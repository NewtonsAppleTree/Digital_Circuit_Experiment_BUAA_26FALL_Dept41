// Student starter: interface only. Replace zero outputs with required RTL.
module wallace_multiplier_8x8 (
    input  logic [7:0]  in1,
    input  logic [7:0]  in2,
    output logic [15:0] res
);

    // TODO: implement according to REQUIREMENTS.md.
    assign res = '0;
endmodule
