// Student starter: interface only. Replace zero outputs with required RTL.
module systolic_pe (
    input  logic        clk,
    input  logic        rst_n,
    input  logic        load,
    input  logic [7:0]  weight_in,
    input  logic [7:0]  data_in,
    input  logic [18:0] psum_in,
    output logic [7:0]  data_out,
    output logic [18:0] psum_out
);

    // TODO: implement according to REQUIREMENTS.md.
    assign data_out = '0;
    assign psum_out = '0;
endmodule
