// Student starter: interface only. Replace zero outputs with required RTL.
module systolic_matmul_4x4 (
    input  logic         clk,
    input  logic         rst_n,
    input  logic         load,
    input  logic [127:0] input_matrix,
    input  logic [127:0] weight,
    output logic [303:0] res
);

    // TODO: implement according to REQUIREMENTS.md.
    assign res = '0;
endmodule
