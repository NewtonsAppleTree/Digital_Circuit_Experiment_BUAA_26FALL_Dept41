#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <iostream>
#include <random>
#include <string>

#include "Vsystolic_matmul_4x4.h"
#include "verilated.h"
#include "verilated_vcd_c.h"

namespace {
using Matrix8 = std::array<std::array<std::uint8_t, 4>, 4>;
using Matrix19 = std::array<std::array<std::uint32_t, 4>, 4>;

vluint64_t simulation_time = 0;

template <std::size_t Words>
void clear_wide(VlWide<Words>& value) {
    for (std::size_t word = 0; word < Words; ++word) value[word] = 0;
}

template <std::size_t Words>
void set_byte(VlWide<Words>& value, int byte_index, std::uint8_t byte) {
    const int bit_index = byte_index * 8;
    const int word_index = bit_index / 32;
    const int word_offset = bit_index % 32;
    const std::uint32_t mask = 0xffU << word_offset;
    value[word_index] = (value[word_index] & ~mask) |
                        (static_cast<std::uint32_t>(byte) << word_offset);
}

template <std::size_t Words>
std::uint32_t get_bits(const VlWide<Words>& value, int bit_index, int width) {
    const int word_index = bit_index / 32;
    const int word_offset = bit_index % 32;
    std::uint64_t joined = value[word_index];
    if (word_offset + width > 32 && word_index + 1 < static_cast<int>(Words)) {
        joined |= static_cast<std::uint64_t>(value[word_index + 1]) << 32U;
    }
    return static_cast<std::uint32_t>(
        (joined >> word_offset) & ((std::uint64_t{1} << width) - 1U));
}

template <std::size_t Words>
void pack_matrix(VlWide<Words>& bus, const Matrix8& matrix) {
    clear_wide(bus);
    for (int row = 0; row < 4; ++row) {
        for (int column = 0; column < 4; ++column) {
            set_byte(bus, row * 4 + column, matrix[row][column]);
        }
    }
}

Matrix19 reference_product(const Matrix8& a, const Matrix8& b) {
    Matrix19 result{};
    for (int row = 0; row < 4; ++row) {
        for (int column = 0; column < 4; ++column) {
            for (int inner = 0; inner < 4; ++inner) {
                result[row][column] +=
                    static_cast<std::uint32_t>(a[row][inner]) * b[inner][column];
            }
        }
    }
    return result;
}

void tick(Vsystolic_matmul_4x4& dut, VerilatedVcdC& trace) {
    dut.clk = 0;
    dut.eval();
    trace.dump(simulation_time++);
    dut.clk = 1;
    dut.eval();
    trace.dump(simulation_time++);
    dut.clk = 0;
    dut.eval();
    trace.dump(simulation_time++);
}

bool result_is_zero(const Vsystolic_matmul_4x4& dut) {
    for (int word = 0; word < 10; ++word) {
        if (dut.res[word] != 0) return false;
    }
    return true;
}

bool check_result(const Vsystolic_matmul_4x4& dut, const Matrix19& expected,
                  const std::string& label) {
    bool passed = true;
    for (int row = 0; row < 4; ++row) {
        for (int column = 0; column < 4; ++column) {
            const int element = row * 4 + column;
            const std::uint32_t got = get_bits(dut.res, element * 19, 19);
            if (got != expected[row][column]) {
                std::cerr << "FAIL " << label << " C[" << row << "][" << column
                          << "]: got=" << got
                          << " expected=" << expected[row][column] << '\n';
                passed = false;
            }
        }
    }
    return passed;
}

bool run_case(Vsystolic_matmul_4x4& dut, VerilatedVcdC& trace,
              const Matrix8& a, const Matrix8& b, const std::string& label,
              int load_cycles = 1, const Matrix19* held_result = nullptr) {
    pack_matrix(dut.input_matrix, a);
    pack_matrix(dut.weight, b);

    dut.load = 1;
    for (int cycle = 0; cycle < load_cycles; ++cycle) {
        tick(dut, trace);
        if (held_result != nullptr &&
            !check_result(dut, *held_result, label + "_load_hold")) {
            return false;
        }
    }

    dut.load = 0;
    tick(dut, trace);  // Capture input_matrix.
    for (int cycle = 0; cycle < 11; ++cycle) tick(dut, trace);

    return check_result(dut, reference_product(a, b), label);
}
}  // namespace

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    Verilated::traceEverOn(true);
    Vsystolic_matmul_4x4 dut;
    VerilatedVcdC trace;
    dut.trace(&trace, 99);
    std::filesystem::create_directories("waves");
    trace.open("waves/systolic_matmul_4x4.vcd");

    clear_wide(dut.input_matrix);
    clear_wide(dut.weight);
    dut.load = 0;
    dut.rst_n = 0;
    tick(dut, trace);
    tick(dut, trace);
    if (!result_is_zero(dut)) {
        std::cerr << "FAIL reset did not clear res\n";
        return 1;
    }
    dut.rst_n = 1;

    const Matrix8 identity = {{{1, 0, 0, 0},
                               {0, 1, 0, 0},
                               {0, 0, 1, 0},
                               {0, 0, 0, 1}}};
    const Matrix8 sample = {{{1, 2, 3, 4},
                             {5, 6, 7, 8},
                             {9, 10, 11, 12},
                             {13, 14, 15, 16}}};
    const Matrix8 max_values = {{{255, 255, 255, 255},
                                 {255, 255, 255, 255},
                                 {255, 255, 255, 255},
                                 {255, 255, 255, 255}}};

    int cases = 0;
    const Matrix19 first_result = reference_product(identity, sample);
    if (!run_case(dut, trace, identity, sample, "identity_times_sample")) return 1;
    ++cases;
    if (!run_case(dut, trace, sample, identity, "sample_times_identity", 3,
                  &first_result)) return 1;
    ++cases;
    if (!run_case(dut, trace, max_values, max_values, "maximum_values")) return 1;
    ++cases;

    std::mt19937 rng(0x4a4U);
    std::uniform_int_distribution<int> byte_value(0, 255);
    for (int test = 0; test < 20; ++test) {
        Matrix8 a{};
        Matrix8 b{};
        for (auto& row : a) {
            for (auto& value : row) value = static_cast<std::uint8_t>(byte_value(rng));
        }
        for (auto& row : b) {
            for (auto& value : row) value = static_cast<std::uint8_t>(byte_value(rng));
        }
        if (!run_case(dut, trace, a, b, "random_" + std::to_string(test))) return 1;
        ++cases;
    }

    // Re-check asynchronous reset after active use.
    dut.rst_n = 0;
    dut.eval();
    if (!result_is_zero(dut)) {
        std::cerr << "FAIL asynchronous reset after matrix tests\n";
        return 1;
    }
    tick(dut, trace);

    trace.close();
    dut.final();
    std::cout << "PASS Level3: " << cases
              << " directed/random 4x4 matrix products; waveform="
              << "waves/systolic_matmul_4x4.vcd\n";
    return 0;
}
