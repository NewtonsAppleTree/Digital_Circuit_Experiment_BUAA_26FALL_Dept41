#include <cstdint>
#include <iostream>

#include "Vwallace_multiplier_8x8.h"
#include "verilated.h"

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    Vwallace_multiplier_8x8 dut;
    std::uint64_t checked = 0;

    for (std::uint32_t a = 0; a < 256; ++a) {
        for (std::uint32_t b = 0; b < 256; ++b) {
            dut.in1 = a;
            dut.in2 = b;
            dut.eval();
            const std::uint32_t expected = a * b;
            if (dut.res != expected) {
                std::cerr << "FAIL wallace_multiplier_8x8: a=" << a
                          << " b=" << b << " got=" << dut.res
                          << " expected=" << expected << '\n';
                return 1;
            }
            ++checked;
        }
    }

    dut.final();
    std::cout << "PASS Level2: exhaustive " << checked
              << " unsigned 8x8 products\n";
    return 0;
}
