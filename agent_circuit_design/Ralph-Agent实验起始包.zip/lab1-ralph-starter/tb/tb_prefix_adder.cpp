#include <cstdint>
#include <iostream>
#include <random>
#include <vector>

#include "Vprefix_adder_19.h"
#include "verilated.h"

namespace {
constexpr std::uint32_t kMask19 = (1U << 19U) - 1U;

bool check_case(Vprefix_adder_19& dut, std::uint32_t a, std::uint32_t b,
                std::uint32_t cin) {
    dut.in1 = a;
    dut.in2 = b;
    dut.cin = cin;
    dut.eval();

    const std::uint32_t expected = a + b + cin;
    const std::uint32_t expected_sum = expected & kMask19;
    const std::uint32_t expected_cout = (expected >> 19U) & 1U;
    if (dut.sum != expected_sum || dut.cout != expected_cout) {
        std::cerr << "FAIL prefix_adder_19: a=" << a << " b=" << b
                  << " cin=" << cin << " got={" << static_cast<int>(dut.cout)
                  << ',' << dut.sum << "} expected={" << expected_cout << ','
                  << expected_sum << "}\n";
        return false;
    }
    return true;
}
}  // namespace

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    Vprefix_adder_19 dut;

    const std::vector<std::uint32_t> edges = {
        0U, 1U, 2U, 0x3ffffU, 0x40000U, 0x7fffeU, 0x7ffffU};
    std::uint64_t checked = 0;

    for (const auto a : edges) {
        for (const auto b : edges) {
            for (std::uint32_t cin = 0; cin <= 1; ++cin) {
                if (!check_case(dut, a, b, cin)) return 1;
                ++checked;
            }
        }
    }

    std::mt19937 rng(0x19addU);
    std::uniform_int_distribution<std::uint32_t> value(0U, kMask19);
    for (int test = 0; test < 250000; ++test) {
        if (!check_case(dut, value(rng), value(rng), value(rng) & 1U)) return 1;
        ++checked;
    }

    dut.final();
    std::cout << "PASS Level1: " << checked
              << " directed/random 19-bit additions\n";
    return 0;
}
