# Lab1：用 Verilator 复现全流水矩阵乘法器

本目录按实验 PDF 的三个层级给出可综合 SystemVerilog 实现和自检查 C++
测试平台。仿真器为 Verilator，不依赖商业 EDA 工具。

本仓库同时用于管理后续的 Agent 驱动 RTL 设计实验：以本实现作为可复现基线，
使用 `snarktank/ralph` + Claude Code 直接迭代 `rtl/`，并由现有 Verilator
测试提供确定性反馈。实验要求以 `REQUIREMENTS.md` 为准，助教分工与执行材料
位于 `docs/`，实验方案课件位于 `slides/`。

## 仓库结构

| 路径 | 内容 |
| --- | --- |
| `rtl/` | 三个层级的 SystemVerilog 实现 |
| `tb/` | Verilator C++ 自检查测试平台 |
| `REQUIREMENTS.md` | 接口、行为约定与验收证据的唯一说明 |
| `docs/` | 助教任务书与实验执行材料 |
| `slides/` | Agent 驱动实验方案课件 |
| `scripts/ralph/` | Ralph 启动脚本、PRD、提示词和跨轮进度 |
| `Ralph使用说明.md` | Ralph 环境准备、图文输入、运行与排错手册 |

## 实现内容

| 层级 | 顶层模块 | 实现 |
| --- | --- | --- |
| Level1 | `prefix_adder_19` | 19 位、纯组合 Kogge-Stone 并行前缀进位加法器 |
| Level2 | `wallace_multiplier_8x8` | 8 个移位部分积、四层 CSA 华莱士压缩、Level1 加法器收尾 |
| Level3 | `systolic_matmul_4x4` | 4×4 定权重 PE 阵列，数据向右流、部分和向下流，每个 PE 均寄存 |

Level3 的每个 PE 复用 Level2 乘法器和 Level1 加法器。RTL 算术数据通路中
没有使用行为级 `*` 乘法。

## 运行

要求 Verilator 5.x、GNU Make 和支持 C++17 的编译器。在本目录执行：

```bash
make test
```

也可以分别执行：

```bash
make lint
make level1
make level2
make level3
```

Level3 会生成 `waves/systolic_matmul_4x4.vcd`，可用 GTKWave 打开：

```bash
gtkwave waves/systolic_matmul_4x4.vcd
```

## Level3 数据打包

PDF 规定了总线宽度，但没有规定 4×4 元素在总线中的排列。本实现明确采用
“低位起、行优先”规则：

```text
input_matrix[8*(4*i+k) +: 8] = A[i][k]
weight[8*(4*k+j) +: 8]       = B[k][j]
res[19*(4*i+j) +: 19]        = C[i][j]
```

其中 `C[i][j] = Σ A[i][k] × B[k][j]`。4 个 8×8 无符号乘积的最大和是
260100，19 位结果槽能够完整容纳。PDF 将输入标成 `input[127:0]`，但
`input` 是 Verilog 关键字，所以合法端口名使用 `input_matrix`。

## Level3 时序协议

1. `rst_n=0` 异步清空阵列和 `res`。
2. 至少保持 `load=1` 一个上升沿：16 个权重并行写入 PE，流水寄存器被冲刷，
   阵列停止计算；已经完成的 `res` 保持可见。
3. 拉低 `load`。第一个上升沿锁存 `input_matrix`。
4. 再等待 11 个上升沿。此时 16 个 19 位结果均已写入 `res`。
5. 若要计算下一组矩阵，重新脉冲一次 `load`；固定权重不变时可再次送入同一
   `weight` 值。

测试平台覆盖复位、连续多周期 `load`、单位矩阵、最大值矩阵和固定种子的随机
矩阵。Level1 执行边界值加 25 万组随机检查；Level2 穷举全部 65536 种输入对。

## Ralph 自主迭代工作流

完整操作步骤与故障排查见 [`Ralph使用说明.md`](Ralph使用说明.md)。

先安装并登录 Claude Code，并确保 `jq`、GNU Make 与 Verilator 可用。Ralph
依赖 Git 区分人工基线与跨轮修改，因此首次启动前必须在一个已提交、测试通过的
干净基线上运行：

```bash
make test
git status --porcelain   # 应无输出
./scripts/ralph/ralph.sh --tool claude 30
```

可以给本轮任务补充一个问题，图片则完全可选：

```bash
# 纯文本
./scripts/ralph/ralph.sh --question "请重点检查 Level2 的部分积压缩" 20

# 文本 + 一张或多张本地图片
./scripts/ralph/ralph.sh \
  --question-file issue.md \
  --image path/to/waveform.png \
  --image path/to/structure.jpg \
  20
```

支持 PNG、JPEG、WebP 和 GIF。`--image` 可以重复出现，但必须同时提供
`--question` 或 `--question-file`；不传图片时会自然进入纯文本流程。可先用
`--dry-run` 校验并查看规范化后的输入，不会启动 Claude 或切换 Git 分支：

```bash
./scripts/ralph/ralph.sh --question "检查时序" --image waveform.png --dry-run
```

用户输入只补充当前 PRD，不会覆盖 `REQUIREMENTS.md` 或测试。每轮 Claude 使用
新上下文，失败修改保留在工作树并由下一轮续修；局部 Story 通过后形成 Git
checkpoint。只有所有 Story 已通过且脚本独立执行 `make test` 返回 0，Ralph 才
接受 `<promise>COMPLETE</promise>`。

旧 `agent/` Python 控制器暂时保留用于历史对照，但不属于 Ralph runtime，也
不会被 `scripts/ralph/ralph.sh` 调用。
