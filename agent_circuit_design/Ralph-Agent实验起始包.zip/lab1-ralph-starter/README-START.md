# Ralph Agent 框架搭建实验起始包

配套《Ralph-Agent框架搭建与三级RTL任务实验手册》（简明版）。

1. 按手册安装工具，在此目录初始化个人 Git 仓库。
2. 将 course-materials 中的 Ralph 启动器与模板复制到手册指定位置。
3. 检查 PRD 三个任务、目标分支和 Agent 指令，启动 Ralph 完成实现。
4. 最终 make test 返回 0，并审阅 RTL 结构、保存日志。

本包包含固定需求、Makefile、三个 C++ 验收测试和五个 RTL 接口骨架。
RTL 输出暂时为零，初始功能测试失败正常；最终须由 Agent 实现。
course-materials 提供原项目适配的 Ralph 编排脚本和手册配置模板。
请保留来源与许可证，不把复用脚本声称为本人原创。
README.md 是原参考工程说明；其中“已实现”和可直接运行的描述不代表本起始包状态。

不含完整 RTL、Git 历史、模型凭据、Python agent 控制器或运行缓存。
模型访问按教师环境配置，不把凭据写入工程。
